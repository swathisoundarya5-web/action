# detection > 2025-09-02 4:17pm
https://universe.roboflow.com/action-detection-rbidn/detection-f8nbo

Provided by a Roboflow user
License: CC BY 4.0

